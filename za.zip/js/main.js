function iriska(){
document.querySelector(".menu").style = "right: 0px"
}
function yopilish(){
document.querySelector(".menu").style = "right: -700px"
}
function och(){
document.querySelector(".menu123").style = "right: 0px"
}
function yopil(){
document.querySelector(".menu123").style = "right: -414px"
}

function iris(){
    document.querySelector(".menu").style = "right: 0px"
    }
    function yopil(){
    document.querySelector(".menu").style = "right: -414px"
    }
    function iris1(){
        document.querySelector(".menu").style = "right: 0px"
        }



        function yopil3(){
            document.querySelector(".menu").style = "right: -450px"
            }
            function menuuu(){
                document.querySelector(".menu").style = "right: 0px !important" 
                }