// function och(){
//     document.querySelector(".menu123").style = "right: 0px"
//     }
//     function yopil(){
//     document.querySelector(".menu123").style = "right: -500px"
//     }

        function ochilishi(){
        document.querySelector(".menu").style = "right:0px;"
        }
        function yop(){
            document.querySelector(".menu").style = "right:-416px;"
            }

    // function yop(){
    //     document.querySelector(".menu").style = "right: 0px"
    //     }
    //     function optkroy(){
    //     document.querySelector(".menu").style = "right: -414px"
    //     }